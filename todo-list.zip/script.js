const input = document.getElementById("todo-item");
const addBtn = document.getElementById("add-btn");
const listDisplay = document.getElementById("todo-list");
const todoItemList = document.querySelector(".todos");

function addTodo(text){

    
    let newElement = document.createElement("div");
    newElement.className = "todo-block";
    newElement.innerHTML = `<li class="current-todo-item">${text}</li>`;
    todoItemList.appendChild(newElement);
    
    let checkbox = document.createElement("input");
    checkbox.className = "check-box";
    checkbox.type = "checkbox";
    newElement.prepend(checkbox);

    let deleteBtn = document.createElement("button");
    deleteBtn.className = "delete-btn";
    deleteBtn.innerHTML = "X";
    deleteBtn.addEventListener('click', function() {
        todoItemList.removeChild(newElement);
    });
    newElement.appendChild(deleteBtn);
    
    input.value = '';
}

addBtn.addEventListener('click', () => { addTodo(input.value) });